library(tidyverse)
library(readxl)
library(readODS)

# Read the data
Conversion <- read.csv("C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\Conversion_Tables\\Area_to_ICB.csv")
Ages <- read.csv("C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\Conversion_Tables\\Raw_Data_2023_2024_NOMIS.csv", skip = 6)
View(Ages)
Ages <- Ages %>%
  select(-`All.Ages`) 
view(Ages)
# Process Male data
selected_rows_M_2023 <- Ages[1:178, ]

# Create new column names based on actual number of columns
new_names_M <- c("Area", paste0("M", 0:90))  # Age columns only

# Rename columns for Male data
colnames(selected_rows_M_2023) <- new_names_M

# Process Female data
selected_rows_F_2023 <- Ages[194:366, ]

# Create new column names based on actual number of columns
new_names_F <- c("Area", paste0("F", 0:90))  # Age columns only

# Rename columns for Female data
colnames(selected_rows_F_2023) <- new_names_F

# Combine datasets and add ICB_Name from Conversion
Combined_Ages_2023 <- selected_rows_M_2023 %>%
  full_join(selected_rows_F_2023, by = "Area") %>%
  left_join(Conversion %>% rename(ICB_Name = ICB_Region), by = "Area") %>%
  select(ICB_Name, Area, starts_with("M"), starts_with("F"))  # Reorder columns
Combined_Ages_2023 <- Combined_Ages_2023 %>%
  na.omit()
# Verify the structure
print("Combined dataset columns:")
print(colnames(Combined_Ages_2023))
View(Combined_Ages_2023)
write.csv(Combined_Ages_2023, 
          "C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\Conversion_Tables\\Combined_M_F_Ages_2023.csv", 
          row.names = FALSE)
################################################################################################################################################################
library(tidyverse)
library(readxl)
library(readODS)

# Process Male data for 2024
selected_rows_M_2024 <- Ages[383:554, ]

# Create new column names for male data
new_names_M <- c("Area", paste0("M", 0:90))  # Age columns only

# Rename columns for Male data
colnames(selected_rows_M_2024) <- new_names_M

# Process Female data for 2024
selected_rows_F_2024 <- Ages[571:742, ]

# Create new column names for female data
new_names_F <- c("Area", paste0("F", 0:90))  # Age columns only

# Rename columns for Female data
colnames(selected_rows_F_2024) <- new_names_F

# Combine datasets and add ICB_Name from Conversion
Combined_Ages_2024 <- selected_rows_M_2024 %>%
  full_join(selected_rows_F_2024, by = "Area") %>%
  left_join(Conversion %>% rename(ICB_Name = ICB_Region), by = "Area") %>%
  select(ICB_Name, Area, starts_with("M"), starts_with("F"))  # Reorder columns
Combined_Ages_2024 <- Combined_Ages_2024 %>%
  na.omit()
# Verify the structure
print("Combined 2024 dataset columns:")
print(colnames(Combined_Ages_2024))
write.csv(Combined_Ages_2024, 
          "C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\Conversion_Tables\\Combined_M_F_Ages_2024.csv", 
          row.names = FALSE)
