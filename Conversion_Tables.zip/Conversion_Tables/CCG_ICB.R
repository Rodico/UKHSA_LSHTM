library(tidyverse)
library(readr)
library(dplyr)
library(readxl)
library(readODS)
install.packages("openxlsx")
library(openxlsx)
ICB <- read_excel("C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\Conversion_Tables\\Population_2012_2022.xlsx",sheet = "Mid-2019 ICB 2024", skip = 3)
ICB <- ICB %>%
  select(
    ICB_Code = 'ICB 2024 Code',
    ICB_Name = 'ICB 2024 Name',
    NHSER_Code = 'NHSER 2024 Code',
    NHSER_Name = 'NHSER 2024 Name'
  )
head(ICB)
CCG <- read_excel("C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\Conversion_Tables\\Population_2019.xlsx",sheet = "Mid-2019 Persons", skip = 6)
CCG <- CCG %>%
  select(
    CCG_Code = 'CCG Code',
    CCG_Name = 'CCG Name',
    NHSER_Code = 'NHSER19 Code',
    NHSER_Name = 'NHSER19 Name'
  )
head(CCG)
CCG_ICB <- ICB %>%
  left_join(CCG, by = "NHSER_Name")
view(CCG_ICB)

CCG_ICB <- CCG_ICB %>%
  select(
  CCG_Code = 'CCG_Code',
  CCG_Name = 'CCG_Name',
  ICB_Code = 'ICB_Code',
  ICB_Name = 'ICB_Name',
  )
head(CCG_ICB)
CCG_ICB_distinct <- CCG_ICB %>%
  distinct(CCG_Code, CCG_Name, ICB_Code, ICB_Name)
head(CCG_ICB_distinct)
View(CCG_ICB_distinct)
write.csv(CCG_ICB_distinct, 
          "C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\Conversion_Tables\\CCG_to_ICB.csv", 
          row.names = FALSE)
