
#Visualisations:

#load Total_GP_appointments_year_month.csv
#load final_GP_appointments_ICB.csv 
#load modeldata_summary.csv

library(tidyverse)
library(ggplot2)
library(ggplot2)
library(dplyr)
library(lubridate)  
library(scales)  


#To retrieve the population for england and for each ICB/region for each year 
modeldata_summary <- modeldata_summary %>% select(YEAR, REGION, ICB_NAME, POPULATION_COUNT)


# Summing population for each year
total_population_england <- modeldata_summary %>%
  group_by(YEAR) %>%
  summarise(Total_Population = sum(POPULATION_COUNT, na.rm = TRUE))  


# This tells you how many GP appointments occur per 100,000 people in a given year in england.
Total_GP_appointments_year_month <- Total_GP_appointments_year_month %>%
                                na.omit(Total_GP_appointments_year_month) %>%  
                                mutate(Month = factor(Month, levels = month.name), Date = make_date(Year, Month, 1)) %>%
                                left_join(total_population_england, by=c("Year"="YEAR")) %>%  # Creates a date column for Year-Month
                                mutate(Rate = (Total_GP_appointments / Total_Population)*100000)  
                          


# Summarize data to get total GP appointments per year
Total_GP_appointments_year <- Total_GP_appointments_year_month %>%
  group_by(Year) %>%
  summarise(Total_GP_Appointments = sum(Total_GP_appointments, na.rm = TRUE))


# Plot: Total GP Appointments per Month over Time
ggplot(data = Total_GP_appointments_year_month, aes(x = Date, y = Rate)) + 
  geom_point(color = "deeppink4",, size = 1.5) +  # Blue points for each month
  geom_line(color = "deeppink3") +   # Blue line connecting monthly totals
  labs(x = "Time (Month-Year)", 
       y = "GP Appointments per 100,000 People", 
       title = "Rates of GP Appointments over Time in England", caption = "Note: Shaded region represents COVID-19 period (2020-2022)") + 
  scale_x_date(date_labels = "%b %Y", date_breaks = "2 month", expand = c(0.01, 0.01)) +  # Show every month
  theme_light() + 
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),  # Rotate labels vertically for better fit
    panel.grid.major.x = element_blank()  # Optionally remove vertical grid lines for clarity
  ) + 
  annotate("rect", xmin = as.Date("2020-01-01"), xmax = as.Date("2022-12-31"), ymin = -Inf, ymax = Inf,
           fill = "grey", alpha = 0.2)  # Highlight COVID-19 period (2020-2022)



# Create region mapping
region_mapping <- list(
  "North East and Yorkshire" = c("NHS North East and North Cumbria Integrated Care Board", 
                                 "NHS Humber and North Yorkshire Integrated Care Board",
                                 "NHS West Yorkshire Integrated Care Board", 
                                 "NHS South Yorkshire Integrated Care Board"),
  
  "North West" = c("NHS Cheshire and Merseyside Integrated Care Board", 
                   "NHS Lancashire and South Cumbria Integrated Care Board",
                   "NHS Greater Manchester Integrated Care Board"),
  
  "Midlands" = c("NHS Staffordshire and Stoke-on-Trent Integrated Care Board", 
                 "NHS Shropshire, Telford and Wrekin Integrated Care Board",
                 "NHS Birmingham and Solihull Integrated Care Board", 
                 "NHS Black Country Integrated Care Board", 
                 "NHS Coventry and Warwickshire Integrated Care Board",
                 "NHS Herefordshire and Worcestershire Integrated Care Board", 
                 "NHS Leicester, Leicestershire and Rutland Integrated Care Board",
                 "NHS Derby and Derbyshire Integrated Care Board", 
                 "NHS Northamptonshire Integrated Care Board",
                 "NHS Nottingham and Nottinghamshire Integrated Care Board", 
                 "NHS Lincolnshire Integrated Care Board"),
  
  "East of England" = c("NHS Norfolk and Waveney Integrated Care Board", 
                        "NHS Suffolk and North East Essex Integrated Care Board",
                        "NHS Hertfordshire and West Essex Integrated Care Board", 
                        "NHS Mid and South Essex Integrated Care Board",
                        "NHS Bedfordshire, Luton and Milton Keynes Integrated Care Board",
                        "NHS Cambridgeshire and Peterborough Integrated Care Board"),
  
  "London" = c("NHS North West London Integrated Care Board", 
               "NHS North Central London Integrated Care Board", 
               "NHS North East London Integrated Care Board",
               "NHS South East London Integrated Care Board", 
               "NHS South West London Integrated Care Board"),
  
  "South East" = c("NHS Kent and Medway Integrated Care Board", 
                   "NHS Surrey Heartlands Integrated Care Board", 
                   "NHS Sussex Integrated Care Board",
                   "NHS Frimley Integrated Care Board", 
                   "NHS Hampshire and the Isle of Wight Integrated Care Board",
                   "NHS Buckinghamshire, Oxfordshire and Berkshire West Integrated Care Board"),
  
  "South West" = c("NHS Cornwall and the Isles of Scilly Integrated Care Board", 
                   "NHS Devon Integrated Care Board", 
                   "NHS Somerset Integrated Care Board",
                   "NHS Bristol, North Somerset and South Gloucestershire Integrated Care Board",
                   "NHS Bath and North East Somerset, Swindon and Wiltshire Integrated Care Board",
                   "NHS Dorset Integrated Care Board", 
                   "NHS Gloucestershire Integrated Care Board")
)


# Transform data and calculate regional averages
library(dplyr)
library(ggplot2)
library(stringr)

total_population_regions <- modeldata_summary %>%
  group_by(YEAR, REGION) %>%
  summarise(POPULATION_COUNT = sum(POPULATION_COUNT, na.rm = TRUE), .groups = "drop") %>%
  mutate(
    REGION = str_to_title(REGION),  # Convert REGION to title case
    REGION = str_replace(REGION, "North East And Yorkshire", "North East and Yorkshire"),  # Correct capitalization
    REGION = str_replace(REGION, "East Of England", "East of England")  # Correct capitalization
  )

# Assign regions to each ICB
regional_total <- final_summary_GP_appointments_ICB %>%
  mutate(
    Region = case_when(
      str_detect(ICB_Name, paste(region_mapping[["North East and Yorkshire"]], collapse = "|")) ~ "North East and Yorkshire",
      str_detect(ICB_Name, paste(region_mapping[["North West"]], collapse = "|")) ~ "North West",
      str_detect(ICB_Name, paste(region_mapping[["Midlands"]], collapse = "|")) ~ "Midlands",
      str_detect(ICB_Name, paste(region_mapping[["East of England"]], collapse = "|")) ~ "East of England",
      str_detect(ICB_Name, paste(region_mapping[["London"]], collapse = "|")) ~ "London",
      str_detect(ICB_Name, paste(region_mapping[["South East"]], collapse = "|")) ~ "South East",
      str_detect(ICB_Name, paste(region_mapping[["South West"]], collapse = "|")) ~ "South West",
      TRUE ~ NA_character_  # Replace "Unknown" with NA
    ),
    Count_gp_appointments = as.numeric(gsub("[^0-9.]", "", as.character(Count_gp_appointments)))  # Convert to numeric
  ) %>%
  filter(!is.na(Count_gp_appointments) & !is.na(Region)) %>%  # Remove Unknown regions
  group_by(Region, Year, Month) %>%
  summarise(Total_GP_Appointments = sum(Count_gp_appointments, na.rm = TRUE), .groups = "drop") %>% # Summarize data 
  mutate(Month = factor(Month, levels = month.name), Date = make_date(Year, Month, 1)) 


#merge the datasets on pulation in each region to GP app in each region to get rates. 
regional_total_rates <- regional_total %>% 
  left_join(total_population_regions, by = c("Year" = "YEAR", "Region" = "REGION")) %>%
  mutate(Rate = round((Total_GP_Appointments / POPULATION_COUNT) * 100000, 0)) # Compute rate per 100,000 population


#using facet_wrap() by region:
ggplot(data = regional_total_rates, aes(x = Date, y = Rate, color = Region)) + 
  geom_line() +  
  geom_point(size=0.5) +  
  facet_wrap(~Region) +  # Separate graphs for each region
  labs(title = "Rates of GP Appointments Over Time by Region in England (2018 - 2024)",
       x = "Time (Month-Year)",
       y = "Number of GP appointments per 100,000 people",
       color = "Region", caption = "Note: Shaded region represents COVID-19 period (2020-2022)") +  # Legend label
  theme_light() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels
        legend.position = "none") +  
  annotate("rect", xmin = as.Date("2020-01-01"), xmax = as.Date("2022-12-31"), ymin = -Inf, ymax = Inf,
           fill = "lightgray", alpha = 0.2) +  # Highlight 2020-2022 period  
  scale_x_date(date_labels = "%b %Y", date_breaks = "12 months")  # Format x-axis as Month-Year, every 3 months


ggplot(data = regional_total_rates, aes(x = Date, y = Rate, color = Region)) + 
  geom_line() +  # Line for each region
  geom_point(size=0.5) +  
  labs(title = "Rates of GP Appointments Over Time by Region in England",
       x = "Time (Month-Year)",
       y = "Number of GP Appointments per 100,000 People",
       color = "Region", caption = "Note: Shaded region represents COVID-19 period (2020-2022)") +  # Legend label
  theme_light() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis labels
        legend.position = "right",  # Position the legend on the right
        legend.key.size = unit(0.5, "cm"),  
        legend.text = element_text(size = 8)) +  
  annotate("rect", xmin = as.Date("2020-01-01"), xmax = as.Date("2022-12-31"), ymin = -Inf, ymax = Inf,
           fill = "grey", alpha = 0.2) +  # Highlight 2020-2022 period  
  scale_x_date(date_labels = "%b %Y", date_breaks = "3 months")  
