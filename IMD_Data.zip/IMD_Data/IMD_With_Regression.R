#-----------------------------------------------------------------------------
# SECTION 1: SETUP AND DATA LOADING
#-----------------------------------------------------------------------------
# Install required packages if not already installed
if (!require("tidyverse")) install.packages("tidyverse")
if (!require("nlme")) install.packages("nlme")
if (!require("zoo")) install.packages("zoo")
if (!require("readODS")) install.packages("readODS")

# Load required libraries
library(readODS)
library(dplyr)
library(tidyr)
library(stringr)
library(ggplot2)
library(nlme)
library(zoo)

# Load the main dataset
load("C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\RCode\\R_Data\\Num_Cases_IMD.RData")

# Print dataset information
cat("\nDataset Information:\n")
cat("Number of rows:", nrow(Num_Cases_IMD), "\n")
cat("Number of columns:", ncol(Num_Cases_IMD), "\n")
cat("\nColumns in dataset:\n")
print(colnames(Num_Cases_IMD))

# Print summary of IMD ranks
cat("\nSummary of IMD Ranks:\n")
cat("E. coli data (rows 1:42):\n")
print(summary(Num_Cases_IMD$IMD_Rank_mean_2019[1:42]))
cat("\nMSSA data (rows 169:210):\n")
print(summary(Num_Cases_IMD$IMD_Rank_mean_2019[169:210]))

#-----------------------------------------------------------------------------
# SECTION 2: TIME SERIES ANALYSIS FUNCTION
#-----------------------------------------------------------------------------
# Purpose: Create time series visualization of rates by IMD groups
# Input: Dataset with IMD ranks and yearly rates
# Output: Time series plot and transformed data

analyze_imd_groups <- function(data, infection_type, n_groups = 6) {
  # Document the columns being used
  cat("\nAnalyzing columns for", infection_type, ":\n")
  cat("IMD column:", "IMD_Rank_mean_2019\n")
  year_cols <- grep("^\\d{4}\\s*to\\s*\\d{4}$", names(data), value = TRUE)
  cat("Year columns:", paste(year_cols, collapse=", "), "\n")
  
  # Remove first 3 year columns (2009-2010 to 2011-2012)
  data <- data %>% 
    select(-matches("^2009 to 2010$|^2010 to 2011$|^2011 to 2012$"))
  
  # Get year columns and convert to numeric
  year_cols <- grep("^\\d{4}\\s*to\\s*\\d{4}$", names(data), value = TRUE)
  data[year_cols] <- lapply(data[year_cols], as.numeric)
  
  # Create IMD groups with actual rank ranges
  rank_breaks <- quantile(data$IMD_Rank_mean_2019, probs = seq(0, 1, length.out = n_groups + 1))
  data$imd_group <- cut(data$IMD_Rank_mean_2019, 
                        breaks = rank_breaks,
                        labels = sprintf("IMD Ranks: %.0f-%.0f",
                                         rank_breaks[-length(rank_breaks)],
                                         rank_breaks[-1]),
                        include.lowest = TRUE)
  
  # Convert to long format
  data_long <- data %>%
    pivot_longer(
      cols = all_of(year_cols),
      names_to = "Year_Range",
      values_to = "Rates"
    ) %>%
    mutate(
      Year_Start = as.numeric(str_extract(Year_Range, "^\\d{4}")),
      Year_End = as.numeric(str_extract(Year_Range, "\\d{4}$")),
      Year = (Year_Start + Year_End) / 2,
      Is_COVID = ifelse(Year >= 2020, 1, 0)
    )
  
  # Find the maximum rate for consistent y-axis scaling
  max_rate <- ceiling(max(data_long$Rates, na.rm = TRUE))
  
  # Create faceted time series plot
  time_series_plot <- ggplot(data_long, aes(x = Year, y = Rates)) +
    annotate("rect", xmin = 2020, xmax = 2022.5, 
             ymin = 0, ymax = Inf, 
             fill = "grey90", alpha = 0.3) +
    geom_point(aes(color = imd_group), alpha = 0.6) +
    geom_smooth(method = "loess", se = FALSE, color = "black", linewidth = 1) +
    facet_wrap(~imd_group, ncol = 2) +
    labs(
      title = paste(infection_type, "Rates Over Time by IMD Rank Groups"),
      subtitle = "Trends by IMD Rank Groups",
      x = "Year",
      y = "Rates per 100,000 population",
      caption = paste("Note: Shaded region represents COVID-19 period (2020-2022)\n",
                      "IMD Ranks are averaged at ICB level")
    ) +
    theme_minimal() +
    theme(
      legend.position = "none",
      plot.title = element_text(size = 14, face = "bold"),
      plot.subtitle = element_text(size = 12),
      strip.text = element_text(size = 10, face = "bold"),
      panel.grid.minor = element_blank(),
      axis.text.x = element_text(angle = 45, hjust = 1)
    ) +
    scale_x_continuous(
      breaks = seq(2012, 2024, by = 2),
      limits = c(2012, 2024)
    ) +
    scale_y_continuous(
      breaks = seq(0, max_rate, by = 20),
      limits = c(0, max_rate),
      expand = c(0, 0)
    )
  
  return(list(
    plot = time_series_plot,
    data = data_long
  ))
}

#-----------------------------------------------------------------------------
# SECTION 3: BOX PLOT ANALYSIS FUNCTION
#-----------------------------------------------------------------------------
# Purpose: Create box plots and calculate summary statistics for different periods
# Input: Dataset with IMD ranks and yearly rates
# Output: Box plot, summary statistics, and transformed data

analyze_imd_covid_pattern <- function(data, infection_type) {
  # Document data columns being used
  cat("\nProcessing data for", infection_type, "Box Plot Analysis:\n")
  pre_covid_cols <- grep("^201[2-9] to", names(data), value = TRUE)
  during_covid_cols <- grep("^20(20|21) to", names(data), value = TRUE)
  post_covid_cols <- grep("^2022 to", names(data), value = TRUE)
  
  cat("Pre-COVID columns:", paste(pre_covid_cols, collapse=", "), "\n")
  cat("During-COVID columns:", paste(during_covid_cols, collapse=", "), "\n")
  cat("Post-COVID columns:", paste(post_covid_cols, collapse=", "), "\n")
  
  # Create a copy of the data and convert columns to numeric
  analysis_data <- data
  all_cols <- c(pre_covid_cols, during_covid_cols, post_covid_cols)
  for(col in all_cols) {
    analysis_data[[col]] <- as.numeric(as.character(analysis_data[[col]]))
  }
  
  # Create IMD groups (quartiles)
  analysis_data$IMD_group <- cut(
    as.numeric(analysis_data$IMD_Rank_mean_2019),
    breaks = quantile(as.numeric(analysis_data$IMD_Rank_mean_2019), 
                      probs = seq(0, 1, by = 0.25),
                      na.rm = TRUE),
    labels = c("Most deprived 25%", "Mid-low deprived", 
               "Mid-high deprived", "Least deprived 25%"),
    include.lowest = TRUE
  )
  
  # Prepare data for box plots with ordered periods
  box_data <- analysis_data %>%
    pivot_longer(
      cols = all_of(all_cols),
      names_to = "Year",
      values_to = "Rate"
    ) %>%
    mutate(
      Year = as.numeric(str_extract(Year, "^\\d{4}")),
      Period = case_when(
        Year < 2020 ~ "1. Pre-COVID (2012-2019)",
        Year < 2022 ~ "2. During COVID (2020-2021)",
        TRUE ~ "3. Post-COVID (2022+)"
      )
    )
  
  # Create box plot
  box_plot <- ggplot(box_data, aes(x = IMD_group, y = Rate, fill = Period)) +
    geom_boxplot(alpha = 0.7, outlier.shape = 1) +
    theme_minimal() +
    labs(
      title = paste(infection_type, "Rate Distribution by IMD Group"),
      subtitle = "Comparing Pre, During, and Post COVID Periods",
      x = "IMD Group",
      y = "Rate per 100,000 population",
      fill = "Time Period"
    ) +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      plot.subtitle = element_text(size = 12),
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "top"
    )
  
  # Calculate comprehensive summary statistics
  summary_stats <- box_data %>%
    group_by(IMD_group, Period) %>%
    summarise(
      n = n(),
      mean_rate = round(mean(Rate, na.rm = TRUE), 2),
      median_rate = round(median(Rate, na.rm = TRUE), 2),
      sd_rate = round(sd(Rate, na.rm = TRUE), 2),
      min_rate = round(min(Rate, na.rm = TRUE), 2),
      max_rate = round(max(Rate, na.rm = TRUE), 2),
      .groups = 'drop'
    )
  
  # Calculate period-to-period changes
  changes_analysis <- box_data %>%
    group_by(IMD_group, Period) %>%
    summarise(mean_rate = mean(Rate, na.rm = TRUE), .groups = 'drop') %>%
    pivot_wider(
      names_from = Period,
      values_from = mean_rate
    ) %>%
    mutate(
      `COVID_Impact` = round(`2. During COVID (2020-2021)` - `1. Pre-COVID (2012-2019)`, 2),
      `Post_COVID_Change` = round(`3. Post-COVID (2022+)` - `2. During COVID (2020-2021)`, 2)
    )
  
  # Print summary statistics
  cat("\n=== Summary Statistics for", infection_type, "===\n")
  print(summary_stats)
  
  cat("\n=== Changes Between Periods ===\n")
  print(changes_analysis)
  
  return(list(
    box_plot = box_plot,
    summary_stats = summary_stats,
    changes_analysis = changes_analysis,
    box_data = box_data
  ))
}

#-----------------------------------------------------------------------------
# SECTION 4: REGRESSION ANALYSIS FUNCTION
#-----------------------------------------------------------------------------
# Purpose: Perform regression analysis and create visualization
# Input: Box plot data with Rate, IMD_group, and Period information
# Output: Regression model, plot, and statistical summary

perform_regression_analysis <- function(results, infection_type) {
  # Get box_data from results
  data <- results$box_data
  
  # Document available columns
  cat("\nRegression Analysis for", infection_type, "\n")
  cat("Available columns:", paste(names(data), collapse=", "), "\n")
  
  # Fit regression model with interaction
  model <- lm(Rate ~ IMD_group * Period, data = data)
  
  # Create regression plot with ordered periods
  reg_plot <- ggplot(data, aes(x = as.numeric(IMD_Rank_mean_2019), y = Rate, color = Period)) +
    geom_point(alpha = 0.4) +
    geom_smooth(method = "lm", se = TRUE) +
    theme_minimal() +
    labs(
      title = paste(infection_type, "- IMD Impact Analysis"),
      subtitle = "Effect of IMD Rank on Rates by Time Period",
      x = "IMD Rank (More Deprived → Less Deprived)",
      y = "Rate per 100,000 population",
      color = "Time Period"
    ) +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      plot.subtitle = element_text(size = 12)
    )
  
  # Calculate key statistics
  model_summary <- summary(model)
  r_squared <- round(model_summary$r.squared, 3)
  adj_r_squared <- round(model_summary$adj.r.squared, 3)
  
  # Print regression results with interpretation
  cat("\n=== Regression Analysis Results ===\n")
  cat("R-squared:", r_squared, "(", adj_r_squared, "adjusted)\n")
  cat("\nModel Coefficients:\n")
  print(coef(model_summary))
  
  # Test for significant differences between periods
  cat("\nANOVA Analysis (Testing Period Effects):\n")
  print(anova(model))
  
  return(list(
    model = model,
    plot = reg_plot,
    r_squared = r_squared,
    summary = model_summary
  ))
}

#-----------------------------------------------------------------------------
# SECTION 5: EXECUTION AND PLOT DISPLAY
#-----------------------------------------------------------------------------
# Purpose: Run all analyses and display results
# Note: Each analysis is run for both E. coli and MSSA data

#--- E. coli Analysis ---#
cat("\n=================== E. coli Analysis ===================\n")
# Run analyses
ecoli_results <- analyze_imd_groups(Num_Cases_IMD[1:42, ], "E. coli")
ecoli_box_results <- analyze_imd_covid_pattern(Num_Cases_IMD[1:42, ], "E. coli")
ecoli_regression <- perform_regression_analysis(ecoli_box_results, "E. coli")

options(tibble.width = Inf)
options(pillar.min_chars = Inf)
options(tibble.print_max = Inf)

# Display E. coli plots
cat("\nDisplaying E. coli Plots:\n")
cat("1. Time Series Plot\n")
print(ecoli_results$plot)
cat("\n2. Box Plot\n")
print(ecoli_box_results$box_plot)
cat("\n3. Regression Plot\n")
print(ecoli_regression$plot)

#--- MSSA Analysis ---#
cat("\n=================== MSSA Analysis ===================\n")
# Run analyses
mssa_results <- analyze_imd_groups(Num_Cases_IMD[169:210, ], "MSSA")
mssa_box_results <- analyze_imd_covid_pattern(Num_Cases_IMD[169:210, ], "MSSA")
mssa_regression <- perform_regression_analysis(mssa_box_results, "MSSA")

# Display MSSA plots
cat("\nDisplaying MSSA Plots:\n")
cat("1. Time Series Plot\n")
print(mssa_results$plot)
cat("\n2. Box Plot\n")
print(mssa_box_results$box_plot)
cat("\n3. Regression Plot\n")
print(mssa_regression$plot)

# After reviewing plots, save them if they look good
cat("\nWould you like to save the plots? Type 'Y' to save:\n")
save_choice <- readline()
if(toupper(save_choice) == "Y") {
  cat("\nSaving plots...\n")
  # E. coli plots
  ggsave("ecoli_timeseries.png", ecoli_results$plot, width = 12, height = 10)
  ggsave("ecoli_boxplot.png", ecoli_box_results$box_plot, width = 12, height = 8)
  ggsave("ecoli_regression.png", ecoli_regression$plot, width = 10, height = 6)
  
  # MSSA plots
  ggsave("mssa_timeseries.png", mssa_results$plot, width = 12, height = 10)
  ggsave("mssa_boxplot.png", mssa_box_results$box_plot, width = 12, height = 8)
  ggsave("mssa_regression.png", mssa_regression$plot, width = 10, height = 6)
  cat("Plots saved successfully!\n")
}

# Display final summary comparing E. coli and MSSA
cat("\n=================== Final Summary ===================\n")
cat("E. coli Analysis:\n")
print(ecoli_box_results$changes_analysis)
cat("\nMSSA Analysis:\n")
print(mssa_box_results$changes_analysis)

cat("\nRegression R-squared values:\n")
cat("E. coli:", ecoli_regression$r_squared, "\n")
cat("MSSA:", mssa_regression$r_squared, "\n")

