# -----------------------------------------------------------------------------
# Setup and Data Loading
# -----------------------------------------------------------------------------

# Install and load required packages
required_packages <- c("car", "lmtest", "nortest", "ggplot2", "tidyverse", "gridExtra")
for(pkg in required_packages) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg)
    library(pkg, character.only = TRUE)
  }
}

# Load the data
# IMPORTANT: Update this path to where your RData file is stored
load("C:\\Users\\dhyay\\OneDrive\\Desktop\\Data Challange\\Data_Challange\\UKHSA_lSHTM\\IMD_Data\\Num_Cases_IMD.RData")

# Prepare E. coli data
ecoli_data <- Num_Cases_IMD[1:42, ]

# Get year columns and convert to numeric
year_cols <- grep("^\\d{4}\\s*to\\s*\\d{4}$", names(ecoli_data), value = TRUE)
year_cols <- year_cols[!grepl("^(2009|2010|2011)", year_cols)]  # Remove 2009-2011

# Convert all year columns to numeric
ecoli_data[year_cols] <- lapply(ecoli_data[year_cols], function(x) as.numeric(as.character(x)))

# Create IMD groups
ecoli_data$IMD_group <- cut(
  as.numeric(ecoli_data$IMD_Rank_mean_2019),
  breaks = quantile(as.numeric(ecoli_data$IMD_Rank_mean_2019), 
                    probs = seq(0, 1, by = 0.25),
                    na.rm = TRUE),
  labels = c("Most deprived 25%", "Mid-low deprived", 
             "Mid-high deprived", "Least deprived 25%"),
  include.lowest = TRUE
)

# Prepare data for analysis
analysis_data <- ecoli_data %>%
  pivot_longer(
    cols = all_of(year_cols),
    names_to = "Year",
    values_to = "Rate"
  ) %>%
  mutate(
    Year = as.numeric(str_extract(Year, "^\\d{4}")),
    Period = case_when(
      Year < 2020 ~ "1. Pre-COVID (2012-2019)",
      Year < 2022 ~ "2. During COVID (2020-2021)",
      TRUE ~ "3. Post-COVID (2022+)"
    )
  )

# Print the first few rows to check the data
print("First few rows of analysis_data:")
print(head(analysis_data))

# Create the regression model
model <- lm(Rate ~ IMD_group * Period, data = analysis_data)

# -----------------------------------------------------------------------------
# Regression Diagnostics Function
# -----------------------------------------------------------------------------

perform_regression_diagnostics <- function(model, data, title = "Model") {
  # Create a list to store all test results
  diagnostics <- list()
  
  # -----------------------------------------------------------------------------
  # 1. Normality Tests
  # -----------------------------------------------------------------------------
  
  # Anderson-Darling test for normality
  ad_test <- nortest::ad.test(residuals(model))
  diagnostics$normality <- list(
    anderson_darling = ad_test,
    shapiro = shapiro.test(residuals(model))
  )
  
  # Q-Q Plot
  qq_plot <- ggplot(data.frame(residuals = residuals(model)), aes(sample = residuals)) +
    stat_qq() +
    stat_qq_line() +
    labs(title = paste(title, "- Normal Q-Q Plot"),
         x = "Theoretical Quantiles",
         y = "Sample Quantiles") +
    theme_minimal()
  
  # -----------------------------------------------------------------------------
  # 2. Homoscedasticity Tests
  # -----------------------------------------------------------------------------
  
  # Breusch-Pagan test
  bp_test <- lmtest::bptest(model)
  diagnostics$homoscedasticity <- list(
    breusch_pagan = bp_test
  )
  
  # Residual vs Fitted Plot
  fitted_resid_plot <- ggplot(data.frame(
    fitted = fitted(model),
    residuals = residuals(model)
  ), aes(x = fitted, y = residuals)) +
    geom_point(alpha = 0.5) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
    geom_smooth(method = "loess", se = FALSE, color = "blue") +
    labs(title = paste(title, "- Residuals vs Fitted"),
         x = "Fitted values",
         y = "Residuals") +
    theme_minimal()
  
  # Scale-Location Plot
  scale_location_plot <- ggplot(data.frame(
    fitted = fitted(model),
    sqrt_std_resid = sqrt(abs(rstandard(model)))
  ), aes(x = fitted, y = sqrt_std_resid)) +
    geom_point(alpha = 0.5) +
    geom_smooth(method = "loess", se = FALSE, color = "blue") +
    labs(title = paste(title, "- Scale-Location Plot"),
         x = "Fitted values",
         y = "√|Standardized residuals|") +
    theme_minimal()
  
  # -----------------------------------------------------------------------------
  # 3. Independence Tests
  # -----------------------------------------------------------------------------
  
  # Durbin-Watson test for autocorrelation
  dw_test <- lmtest::dwtest(model)
  diagnostics$independence <- list(
    durbin_watson = dw_test
  )
  
  # -----------------------------------------------------------------------------
  # 4. Linearity Tests
  # -----------------------------------------------------------------------------
  
  # RESET test
  diagnostics$linearity <- list(
    reset_test = lmtest::resettest(model)
  )
  
  # -----------------------------------------------------------------------------
  # 5. Multicollinearity Tests
  # -----------------------------------------------------------------------------
  
  # Variance Inflation Factors
  vif_results <- car::vif(model)
  diagnostics$multicollinearity <- list(
    vif = vif_results
  )
  
  # -----------------------------------------------------------------------------
  # 6. Influence Diagnostics
  # -----------------------------------------------------------------------------
  
  # Cook's Distance Plot
  cooks_plot <- ggplot(data.frame(
    index = 1:length(cooks.distance(model)),
    cooks_d = cooks.distance(model)
  ), aes(x = index, y = cooks_d)) +
    geom_point(alpha = 0.5) +
    geom_hline(yintercept = 4/length(cooks.distance(model)), 
               linetype = "dashed", color = "red") +
    labs(title = paste(title, "- Cook's Distance"),
         x = "Observation Index",
         y = "Cook's Distance") +
    theme_minimal()
  
  # -----------------------------------------------------------------------------
  # Return Results
  # -----------------------------------------------------------------------------
  
  # Combine all plots
  plots <- list(
    qq_plot = qq_plot,
    fitted_resid_plot = fitted_resid_plot,
    scale_location_plot = scale_location_plot,
    cooks_plot = cooks_plot
  )
  
  # Print summary of all tests
  cat("\n=== Regression Diagnostics Summary ===\n")
  cat("\n1. Normality Tests:\n")
  print(diagnostics$normality)
  
  cat("\n2. Homoscedasticity Test:\n")
  print(diagnostics$homoscedasticity)
  
  cat("\n3. Independence Test:\n")
  print(diagnostics$independence)
  
  cat("\n4. Linearity Test:\n")
  print(diagnostics$linearity)
  
  cat("\n5. Multicollinearity (VIF):\n")
  print(diagnostics$multicollinearity)
  
  return(list(
    diagnostics = diagnostics,
    plots = plots
  ))
}

# -----------------------------------------------------------------------------
# Run Diagnostics
# -----------------------------------------------------------------------------

# Run diagnostics on the model
diagnostics_results <- perform_regression_diagnostics(model, analysis_data, "E. coli Model")

# Display all plots in a grid
plot_grid <- grid.arrange(
  diagnostics_results$plots$qq_plot,
  diagnostics_results$plots$fitted_resid_plot,
  diagnostics_results$plots$scale_location_plot,
  diagnostics_results$plots$cooks_plot,
  ncol = 2
)

# Save plots
ggsave("diagnostic_plots.png", plot_grid, width = 12, height = 10)

# Print specific test results
cat("\nKey Test Results:\n")
cat("\nShapiro-Wilk normality test p-value:", 
    round(diagnostics_results$diagnostics$normality$shapiro$p.value, 4))
cat("\nBreusch-Pagan test p-value:", 
    round(diagnostics_results$diagnostics$homoscedasticity$breusch_pagan$p.value, 4))
cat("\nDurbin-Watson test p-value:", 
    round(diagnostics_results$diagnostics$independence$durbin_watson$p.value, 4))

