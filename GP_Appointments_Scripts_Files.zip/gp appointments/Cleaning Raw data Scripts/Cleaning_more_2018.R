#works for More_2018 folders 

library(tidyverse)
library(purrr)

# Define the folder where CSV files are stored
folder_path <- "~/Desktop/gp appointments/More_2018"

# Get a list of all CSV files in the folder
file_list <- list.files(path = folder_path, pattern = "*.csv", full.names = TRUE)

# Function to clean and process each file
process_file <- function(file) {
  
  month_name <- str_extract(file, "(?i)(January|February|March|April|May|June|July|August|September|October|November|December)")
  
  read_csv(file)%>%
    select(CCG_CODE,CCG_ONS_CODE, CCG_NAME, SUBREGION_ONS_CODE, REGION_ONS_CODE, APPOINTMENT_STATUS, COUNT_OF_APPOINTMENTS) %>%
    group_by(CCG_CODE, CCG_ONS_CODE, CCG_NAME, SUBREGION_ONS_CODE, REGION_ONS_CODE) %>%
    summarise(Total=sum(COUNT_OF_APPOINTMENTS), .groups = "drop")%>%
    mutate(Month = month_name)  # Add extracted month
}

# Apply function to all files and store results in a list
processed_files <- map(file_list, process_file)

# Optionally combine into one dataset
combined_data_more_2018 <- bind_rows(processed_files, .id = "source_file")

# Save each cleaned file (optional)
walk2(processed_files, file_list, ~ write_csv(.x, gsub(".csv", "_cleaned.csv", .y)))

write_csv(combined_data_more_2018, "combined_data_more_2018.csv")