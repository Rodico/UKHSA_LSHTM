#works for 2020, 2019, 2018 folders 

library(tidyverse)
library(purrr)

# Define the folder where CSV files are stored
folder_path <- "~/Desktop/gp appointments/2019"

# Get a list of all CSV files in the folder
file_list <- list.files(path = folder_path, pattern = "*.csv", full.names = TRUE)

# Function to clean and process each file
process_file <- function(file) {
  
  month_name <- str_extract(file, "(?i)(January|February|March|April|May|June|July|August|September|October|November|December)")
  
  read_csv(file, col_names = FALSE)%>%
    slice(11:266) %>%  # change to 196 for 2020, 11:266 for 2019 and 2018, 
    select(X1, X2, X3, X4, X7, X9, X10, X11) %>%
    rename(
      Type = X1,
      NHS_area_code = X2,
      ONS_code = X3,
      Name = X4,
      Count_gp_appointments = X7,
      Attended = X9,
      Did_not_attend = X10,
      Unknown = X11
    )%>%
    mutate(Month = month_name)  # Add extracted month
}

# Apply function to all files and store results in a list
processed_files <- map(file_list, process_file)

# Optionally combine into one dataset
combined_data_2019 <- bind_rows(processed_files, .id = "source_file")

# Save each cleaned file (optional)
walk2(processed_files, file_list, ~ write_csv(.x, gsub(".csv", "_cleaned.csv", .y)))


#run the following for when cleaning and combing the 2019 datasets
#combined_data_2019 <- combined_data_2019 %>% slice(-c(1,256,257,513,1281,1537,1793,2049,2304,2305,2561,2817))

write_csv(combined_data_2019, "combined_data_2019.csv")

