#Script for the final GP apointments dataset: 

library(tidyverse)

#setwd(/Users/ishamathur/Desktop/gp appointments/Combined_cleaned_data)


#load all the combined_data_xxxx datasets. 
#load New_CCG_to_ICB.csv


#Filter the following to only include CCG for 2018-2022, and ICB 2022-2023: 

#for 2018 from octo-dec
# Filter only rows where "Type" == "CCG"
combined_data_2018_ICB <- combined_data_2018 %>%
  filter(Type == "CCG") %>%
  left_join(New_CCG_to_ICB, by = c("ONS_code" = "CCG_Code")) #merge to get the ICB codes into the dataset

write_csv(combined_data_2018_ICB, "combined_data_2018_ICB_new.csv")


#for 2018 jan-sep
combined_data_more_2018_ICB <- combined_data_more_2018 %>%
  left_join(New_CCG_to_ICB, by = c("CCG_ONS_CODE" = "CCG_Code")) #merge to get the ICB codes into the dataset

write_csv(combined_data_more_2018_ICB, "combined_data_more_2018_ICB_new.csv")


#for 2019
# Filter only rows where "Type" == "CCG"
combined_data_2019_ICB <- combined_data_2019 %>%
  filter(Type == "CCG") %>%
  left_join(New_CCG_to_ICB, by = c("ONS_code" = "CCG_Code")) #merge to get the ICB codes into the dataset

write_csv(combined_data_2019_ICB, "combined_data_2019_ICB_new.csv")

#for 2020
# Filter only rows where "Type" == "CCG"
combined_data_2020_ICB <- combined_data_2020 %>%
  filter(Type == "CCG") %>%
  left_join(New_CCG_to_ICB, by = c("ONS_code" = "CCG_Code")) #merge to get the ICB codes into the dataset

write_csv(combined_data_2020_ICB, "combined_data_2020_ICB_new.csv")

#for 2021
# Filter only rows where "Type" == "CCG"
combined_data_2021_ICB <- combined_data_2021 %>%
  filter(Type == "CCG") %>%
  left_join(New_CCG_to_ICB, by = c("ONS_code" = "CCG_Code")) #merge to get the ICB codes into the dataset

write_csv(combined_data_2021_ICB, "combined_data_2021_ICB_new.csv")

#for 2022
# Filter only rows where "Type" == "CCG and ICB"
combined_data_2022_ICB <- combined_data_2022 %>%
  filter(Type %in% c("CCG", "ICB")) %>%
  left_join(New_CCG_to_ICB, by = c("ONS_code" = "CCG_Code")) #merge to get the ICB codes into the dataset

write_csv(combined_data_2022_ICB, "combined_data_2022_ICB_new.csv")

#for 2023
# Filter only rows where "Type" == "ICB"
combined_data_2023_ICB <- combined_data_2023 %>%
  filter(Type == "ICB")

write_csv(combined_data_2023_ICB, "combined_data_2023_ICB.csv")


#for 2024
# Filter only rows where "Type" == "ICB"
combined_data_2024_ICB <- combined_data_2024 %>%
  filter(Type == "ICB")

write_csv(combined_data_2024_ICB, "combined_data_2024_ICB.csv")





