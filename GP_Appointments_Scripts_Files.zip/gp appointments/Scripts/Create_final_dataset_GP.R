library(tidyverse)


#The below code is how we created the new CCG to ICB conversion table:
# x <- data.frame(final_gp_app_overall[is.na(final_gp_app_overall$ICB_Name), ]) %>% filter(Type=="CCG") %>% distinct(Name, .keep_all = TRUE) %>% select(ONS_code, Name) #rows where we have missing ICB name. %>% 
#New_CCG_to_ICB <- bind_rows(Updated_CCG_to_ICB,CCG_ICB)
#write_csv(New_CCG_to_ICB, "New_CCG_to_ICB.csv")


###################### 
#Load all th combined datasets

#Adding the 2018 Jan-Sep to the 2018 oct-dec dataset
combined_data_more_2018_ICB_new <- combined_data_more_2018_ICB_new %>% 
                rename(Name=CCG_NAME, ONS_code=CCG_ONS_CODE, NHS_area_code=CCG_CODE, Count_gp_appointments=Total) %>% 
                select(-c(SUBREGION_ONS_CODE,REGION_ONS_CODE)) %>% 
                mutate(Count_gp_appointments = as.character(Count_gp_appointments)) #change column to character for binding rows.

combined_data_2018_ICB_new <- bind_rows(combined_data_2018_ICB_new, combined_data_more_2018_ICB_new) %>% #combine these two datasets to complete 2018
  mutate(Type = replace_na(Type, "CCG"))  # Replace NA values in Type with "CCG"

#Add a year column to each dataset
combined_data_2018_ICB_new <- combined_data_2018_ICB_new %>% mutate(Year=2018)
combined_data_2019_ICB_new <- combined_data_2019_ICB_new %>% mutate(Year=2019)
combined_data_2020_ICB_new <- combined_data_2020_ICB_new %>% mutate(Year=2020)
combined_data_2021_ICB_new <- combined_data_2021_ICB_new %>% mutate(Year=2021)
combined_data_2022_ICB_new <- combined_data_2022_ICB_new %>% mutate(Year=2022)
combined_data_2023_ICB <- combined_data_2023_ICB %>% mutate(Year=2023)
combined_data_2024_ICB <- combined_data_2024_ICB %>% mutate(Year=2024)


library(dplyr)
library(tidyr)  # Needed for complete()

# Combine all datasets
final_gp_app_overall <- bind_rows(combined_data_2018_ICB_new, combined_data_2019_ICB_new, combined_data_2020_ICB_new,
                                  combined_data_2021_ICB_new, combined_data_2022_ICB_new, combined_data_2023_ICB, 
                                  combined_data_2024_ICB) 


# Convert Count_gp_appointments to numeric safely
final_gp_app_overall <- final_gp_app_overall %>% 
  mutate(Count_gp_appointments = as.numeric(gsub("[^0-9.]", "", Count_gp_appointments)))  # Remove non-numeric characters


#Create a subset where ICB already existed from the start in the original dataset:
ICB_table <- final_gp_app_overall %>%
  filter(Type=="ICB")  %>%
  group_by(Month, Year) %>%
  select(Type, ONS_code, Name, Count_gp_appointments, Month, Year) %>%
  rename(ICB_Code=ONS_code, ICB_Name=Name)
  
#Create a subset where we had CCG, but now want the ICB codes and names as columns:
CCG_table <- final_gp_app_overall %>%
  filter(Type=="CCG")  %>% #2018 jan-sep are NA in the type column. 
  group_by(Month, Year) %>%
  select(Type, Name, ICB_Code, ICB_Name, Count_gp_appointments, Month, Year) %>% distinct(Name,.keep_all = TRUE) #so that one CCG is not repeated as some CCGs were split into 4 ICBs

#Combined the two datasets above.
final_GP_appointments_ICB <- bind_rows(ICB_table, CCG_table) %>% 
  mutate(across(where(is.character), ~ replace_na(., "Unknown"))) # Replace NA in character columns with "Unknown"

# Create all Month-Year combinations and summarize total appointments for each month and year. 
Total_GP_appointments <- final_GP_appointments_ICB  %>%
  group_by(Month, Year) %>%
  summarise(Total_GP_appointments = sum(Count_gp_appointments, na.rm = TRUE), .groups = "drop") %>%
  complete(Month, Year, fill = list(Total_GP_appointments = NA))  # Ensures all Month-Year pairs exist

write_csv(Total_GP_appointments, "Total_GP_appointments_year_month.csv") #this dataset has total GP appointments for each year and month. 

write_csv(final_GP_appointments_ICB, "final_summary_GP_appointments_ICB.csv")  #this dataset has total GP appointments for each year and month by ICB code. 
#Although for the CCG that were divided into 4 we had to pick one. 


