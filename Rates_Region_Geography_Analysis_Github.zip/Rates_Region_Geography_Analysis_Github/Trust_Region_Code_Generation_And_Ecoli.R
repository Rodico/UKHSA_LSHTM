#Creates the GIF animation for the powerpoint which has
# regions highlightedd over the financial year and creates the Ecoli
#Rates graph 

# Install and load required packages
install.packages(c("readxl", "tidyverse", "ggridges", "scales"))
# Install required packages
install.packages(c("rnaturalearth", "rnaturalearthdata", "sf"))

# Install required packages
install.packages(c("gganimate", "gifski"))

# Load the packages
library(gganimate)
library(gifski)

# Load the packages
library(rnaturalearth)
library(rnaturalearthdata)
library(sf)

# Load required libraries
library(tidyverse)
library(ggridges)
library(scales)
library(readxl)
library(ggplot2)

# Set working directory
setwd("~/Data")
trust_data <- read_excel("Trust_Rates.xlsx")
head(trust_data)
glimpse(trust_data)

names(trust_data)

# Read data
trust_data <- read_csv("Trust_Rates_final.csv")

# Create region mapping
region_mapping <- list(
  "North East and Yorkshire" = c("NHS North East and North Cumbria", "NHS Humber and North Yorkshire", 
                                 "NHS West Yorkshire", "NHS South Yorkshire"),
  "North West" = c("NHS Cheshire and Merseyside", "NHS Lancashire and South Cumbria", 
                   "NHS Greater Manchester"),
  "Midlands" = c("NHS Staffordshire and Stoke-on-Trent", "NHS Shropshire, Telford and Wrekin",
                 "NHS Birmingham and Solihull", "NHS Black Country", "NHS Coventry and Warwickshire",
                 "NHS Herefordshire and Worcestershire", "NHS Leicester, Leicestershire and Rutland",
                 "NHS Derby and Derbyshire", "NHS Northamptonshire", 
                 "NHS Nottingham and Nottinghamshire", "NHS Lincolnshire"),
  "East of England" = c("NHS Norfolk and Waveney", "NHS Suffolk and North East Essex",
                        "NHS Hertfordshire and West Essex", "NHS Mid and South Essex",
                        "NHS Bedfordshire, Luton and Milton Keynes", 
                        "NHS Cambridgeshire and Peterborough"),
  "London" = c("NHS North West London", "NHS North Central London", "NHS North East London",
               "NHS South East London", "NHS South West London"),
  "South East" = c("NHS Kent and Medway", "NHS Surrey Heartlands", "NHS Sussex",
                   "NHS Frimley", "NHS Hampshire and Isle of Wight", 
                   "NHS Buckinghamshire, Oxfordshire and Berkshire West"),
  "South West" = c("NHS Cornwall and the Isles of Scilly", "NHS Devon", "NHS Somerset",
                   "NHS Bristol, North Somerset and South Gloucestershire", 
                   "NHS Bath and North East Somerset, Swindon and Wiltshire",
                   "NHS Dorset", "NHS Gloucestershire")
)

# Transform data and calculate regional averages
regional_averages <- trust_data %>%
  select(Species, `Integrated care board (ICB)`, 
         `2014 to 2015`:`2023 to 2024`) %>%
  mutate(
    Region = case_when(
      str_detect(`Integrated care board (ICB)`, paste(region_mapping[["North East and Yorkshire"]], collapse = "|")) ~ "North East and Yorkshire",
      str_detect(`Integrated care board (ICB)`, paste(region_mapping[["North West"]], collapse = "|")) ~ "North West",
      str_detect(`Integrated care board (ICB)`, paste(region_mapping[["Midlands"]], collapse = "|")) ~ "Midlands",
      str_detect(`Integrated care board (ICB)`, paste(region_mapping[["East of England"]], collapse = "|")) ~ "East of England",
      str_detect(`Integrated care board (ICB)`, paste(region_mapping[["London"]], collapse = "|")) ~ "London",
      str_detect(`Integrated care board (ICB)`, paste(region_mapping[["South East"]], collapse = "|")) ~ "South East",
      str_detect(`Integrated care board (ICB)`, paste(region_mapping[["South West"]], collapse = "|")) ~ "South West"
    )
  ) %>%
  group_by(Species, Region) %>%
  summarise(across(`2014 to 2015`:`2023 to 2024`, 
                   ~mean(as.numeric(ifelse(. %in% c("[x]", ""), NA, .)), na.rm = TRUE))) %>%
  pivot_longer(
    cols = `2014 to 2015`:`2023 to 2024`,
    names_to = "year",
    values_to = "average_rate"
  ) %>%
  # Change this to extract the second year instead of the first
  mutate(year = as.numeric(str_extract(year, "^\\d{4}"))) %>%
  filter(!is.na(average_rate))

# Function to create plot with COVID-19 shading
create_plot <- function(data, species_name) {
  ggplot() +
    # Add COVID-19 period shading
    annotate("rect", xmin = 2020, xmax = 2022, ymin = -Inf, ymax = Inf,
             fill = "grey", alpha = 0.2) +
    # Add the data lines
    geom_line(data = data, 
              aes(x = year, y = average_rate, color = Region, group = Region),
              size = 1) +
    geom_point(data = data,
               aes(x = year, y = average_rate, color = Region),
               size = 3) +
    scale_x_continuous(breaks = 2014:2023, limits = c(2014, 2023)) +
    scale_y_continuous(
      limits = c(50, 100),
      breaks = seq(50, 100, by = 10)
    ) +
    scale_color_brewer(palette = "Set2") +
    labs(
      title = paste("Average", species_name, "bacteraemia rates, England Regions, by financial year  (2014-2024)"),
      x = "Year",
      y = "Average Rate per 100,000 (%)",
      caption = "Note: Shaded area indicates COVID-19 period (2020-2022)"
    ) +
    theme_minimal() +
    theme(
      legend.position = "right",
      plot.title = element_text(size = 14, face = "bold"),
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.text = element_text(size = 10),
      panel.grid.major = element_line(color = "grey90"),
      panel.grid.minor = element_line(color = "grey95"),
      plot.caption = element_text(hjust = 0, face = "italic")
    )
}

# Create plot for E. coli
ecoli_plot <- regional_averages %>%
  filter(str_detect(Species, "Escherichia")) %>%
  create_plot("E. coli")

# Print plot
print(ecoli_plot)

# Load UK counties data
uk_counties <- ne_states(country = "united kingdom", returnclass = "sf")

# Add debugging to see both Birmingham and Solihull entries
print("Checking Birmingham and Solihull entries:")
print(uk_counties$gns_name[grepl("Birmingham|Solihull", uk_counties$gns_name, ignore.case = TRUE)])

# Updated region mapping code with Birmingham and Solihull grouped together
uk_counties$nhs_region <- case_when(
  # Birmingham and Solihull explicitly grouped together
  grepl("Birmingham|Solihull, Borough of", uk_counties$gns_name, ignore.case = TRUE) ~ "Midlands",
  
  # North East and Yorkshire
  grepl("Northumberland|Durham|Newcastle|Gateshead|Sunderland|Middlesbrough|York|North Yorkshire|Hull|Leeds|Sheffield|Bradford|Calderdale|Kirklees|Wakefield|Doncaster|Rotherham|Barnsley|East Riding|Scarborough|Whitby|Ryedale|Cleveland|North Tyneside|South Tyneside|Harrogate|Hambleton", uk_counties$gns_name, ignore.case = TRUE) ~ "North East and Yorkshire",
  
  # North West
  grepl("Cheshire|Lancashire|Manchester|Liverpool|Merseyside|Cumbria|Wirral|Sefton|Knowsley|St. Helens|Halton|Warrington|Stockport|Trafford|Bolton|Bury|Rochdale|Oldham|Tameside|Salford|Blackpool|Blackburn|Wigan|Preston|Burnley|Pendle", uk_counties$gns_name, ignore.case = TRUE) ~ "North West",
  
  # Rest of Midlands
  grepl("Staffordshire|Stoke|Shropshire|Telford|Worcester|Leicester|Derby|Derbyshire|Northampton|Nottingham|Lincoln|Rutland|Wolverhampton|Walsall|Sandwell|Dudley|Coventry|Herefordshire|Warwick|Warwickshire|Black Country|Lincolnshire|Nottinghamshire|West Midlands", uk_counties$gns_name, ignore.case = TRUE) ~ "Midlands",
  
  # East of England
  grepl("Norfolk|Suffolk|Essex|Hertfordshire|Bedford|Luton|Milton Keynes|Cambridge|Peterborough|Thurrock|Southend|Central Bedfordshire|Waveney|North Essex|West Essex|South Essex|East Essex", uk_counties$gns_name, ignore.case = TRUE) ~ "East of England",
  
  # London
  grepl("London|Westminster|Camden|Islington|Hackney|Tower Hamlets|Greenwich|Lewisham|Southwark|Lambeth|Wandsworth|Hammersmith|Kensington|Chelsea|Brent|Harrow|Ealing|Hounslow|Richmond|Kingston|Merton|Sutton|Croydon|Bromley|Bexley|Havering|Barking|Redbridge|Newham|Waltham Forest|Haringey|Enfield|Barnet|Hillingdon", uk_counties$gns_name, ignore.case = TRUE) ~ "London",
  
  # South East
  grepl("Kent|Surrey|Sussex|Hampshire|Berkshire|Buckinghamshire|Oxford|Isle of Wight|Medway|Brighton|Portsmouth|Southampton|Reading|Slough|Windsor|Wokingham|Bracknell|Frimley|Oxfordshire|West Berkshire|East Sussex|West Sussex", uk_counties$gns_name, ignore.case = TRUE) ~ "South East",
  
  # South West
  grepl("Cornwall|Devon|Somerset|Bristol|Bath|Wiltshire|Dorset|Gloucester|Swindon|Torbay|Plymouth|Poole|Bournemouth|Scilly|South Gloucestershire|North Somerset|East Somerset|West Somerset|North Devon|South Devon|East Devon|West Devon", uk_counties$gns_name, ignore.case = TRUE) ~ "South West",
  
  TRUE ~ NA_character_
)

# Add debugging to see their assigned regions
print("After mapping - checking Birmingham and Solihull regions:")
print(uk_counties %>% 
        filter(grepl("Birmingham|Solihull", gns_name, ignore.case = TRUE)) %>% 
        select(gns_name, nhs_region))

# Join the data with relationship specified
map_data <- uk_counties %>%
  filter(!is.na(nhs_region)) %>%
  left_join(
    regional_averages %>% 
      filter(str_detect(Species, "Escherichia")),
    by = c("nhs_region" = "Region"),
    relationship = "many-to-many"
  )

# Create the animated map with the updated title
animated_map <- ggplot(data = map_data) +
  geom_sf(aes(fill = average_rate), color = "white", size = 0.2) +
  scale_fill_viridis_c(
    name = "Rate (%)",
    limits = c(50, 100),
    option = "plasma",
    direction = -1,
    na.value = "grey90"
  ) +
  theme_void() +
  labs(
    title = "E. coli bacteraemia rates, U.K Regions, by financial year (2014-2024)",
    subtitle = "Year: {current_frame}"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    plot.subtitle = element_text(hjust = 0.5, size = 12),
    legend.position = "right",
    legend.title = element_text(size = 10),
    legend.text = element_text(size = 8),
    plot.margin = margin(1, 1, 1, 1, "cm")
  ) +
  transition_manual(year)

# Create and save the animation
anim <- animate(
  animated_map,
  nframes = length(unique(regional_averages$year)),
  fps = 2,
  width = 800,
  height = 800,
  renderer = gifski_renderer()
)

print(anim)

# Save the animation
anim_save("ecoli_rates_map.gif", animation = anim)

