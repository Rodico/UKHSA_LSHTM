#Creates Sections of maps for each section pre during and post covid
#For ecoli

# Install and load required packages
library(sf)
library(rnaturalearth)
library(dplyr)
library(ggplot2)
library(patchwork)
library(tidyverse)

# Set working directory
setwd("~/Data")
trust_data <- read_csv("Trust_Rates_final.csv")

# Load UK counties data
uk_counties <- ne_states(country = "united kingdom", returnclass = "sf")

# Region mapping
uk_counties$nhs_region <- case_when(
  # Birmingham and Solihull explicitly grouped together
  grepl("Birmingham|Solihull, Borough of", uk_counties$gns_name, ignore.case = TRUE) ~ "Midlands",
  
  # North East and Yorkshire
  grepl("Northumberland|Durham|Newcastle|Gateshead|Sunderland|Middlesbrough|York|North Yorkshire|Hull|Leeds|Sheffield|Bradford|Calderdale|Kirklees|Wakefield|Doncaster|Rotherham|Barnsley|East Riding|Scarborough|Whitby|Ryedale|Cleveland|North Tyneside|South Tyneside|Harrogate|Hambleton", uk_counties$gns_name, ignore.case = TRUE) ~ "North East and Yorkshire",
  
  # North West
  grepl("Cheshire|Lancashire|Manchester|Liverpool|Merseyside|Cumbria|Wirral|Sefton|Knowsley|St. Helens|Halton|Warrington|Stockport|Trafford|Bolton|Bury|Rochdale|Oldham|Tameside|Salford|Blackpool|Blackburn|Wigan|Preston|Burnley|Pendle", uk_counties$gns_name, ignore.case = TRUE) ~ "North West",
  
  # Rest of Midlands
  grepl("Staffordshire|Stoke|Shropshire|Telford|Worcester|Leicester|Derby|Derbyshire|Northampton|Nottingham|Lincoln|Rutland|Wolverhampton|Walsall|Sandwell|Dudley|Coventry|Herefordshire|Warwick|Warwickshire|Black Country|Lincolnshire|Nottinghamshire|West Midlands", uk_counties$gns_name, ignore.case = TRUE) ~ "Midlands",
  
  # East of England
  grepl("Norfolk|Suffolk|Essex|Hertfordshire|Bedford|Luton|Milton Keynes|Cambridge|Peterborough|Thurrock|Southend|Central Bedfordshire|Waveney|North Essex|West Essex|South Essex|East Essex", uk_counties$gns_name, ignore.case = TRUE) ~ "East of England",
  
  # London
  grepl("London|Westminster|Camden|Islington|Hackney|Tower Hamlets|Greenwich|Lewisham|Southwark|Lambeth|Wandsworth|Hammersmith|Kensington|Chelsea|Brent|Harrow|Ealing|Hounslow|Richmond|Kingston|Merton|Sutton|Croydon|Bromley|Bexley|Havering|Barking|Redbridge|Newham|Waltham Forest|Haringey|Enfield|Barnet|Hillingdon", uk_counties$gns_name, ignore.case = TRUE) ~ "London",
  
  # South East
  grepl("Kent|Surrey|Sussex|Hampshire|Berkshire|Buckinghamshire|Oxford|Isle of Wight|Medway|Brighton|Portsmouth|Southampton|Reading|Slough|Windsor|Wokingham|Bracknell|Frimley|Oxfordshire|West Berkshire|East Sussex|West Sussex", uk_counties$gns_name, ignore.case = TRUE) ~ "South East",
  
  # South West
  grepl("Cornwall|Devon|Somerset|Bristol|Bath|Wiltshire|Dorset|Gloucester|Swindon|Torbay|Plymouth|Poole|Bournemouth|Scilly|South Gloucestershire|North Somerset|East Somerset|West Somerset|North Devon|South Devon|East Devon|West Devon", uk_counties$gns_name, ignore.case = TRUE) ~ "South West",
  
  TRUE ~ NA_character_
)

# Create period averages from regional_averages
period_averages <- regional_averages %>%
  filter(str_detect(Species, "Escherichia")) %>%  # Changed from MSSA to Escherichia
  mutate(period = case_when(
    year < 2020 ~ "Pre-COVID (2014-2019)",
    year >= 2020 & year <= 2022 ~ "During COVID (2020-2022)",
    year > 2022 ~ "Post-COVID (2023)"
  )) %>%
  group_by(Species, Region, period) %>%
  summarise(average_rate = mean(average_rate, na.rm = TRUE))

# Function to create period map
create_period_map <- function(period_name, data) {
  map_data <- uk_counties %>%
    filter(!is.na(nhs_region)) %>%
    left_join(
      data %>% 
        filter(period == period_name),
      by = c("nhs_region" = "Region"),
      relationship = "many-to-many"
    )
  
  ggplot(data = map_data) +
    geom_sf(aes(fill = average_rate), color = "white", size = 0.2) +
    scale_fill_viridis_c(
      name = "Rate (%)",
      limits = c(50, 100),  # Changed from (10, 30) to (50, 100) for E. coli
      option = "plasma",
      direction = -1,
      na.value = "grey90"
    ) +
    theme_void() +
    labs(
      title = period_name,
      subtitle = "E. coli Rates by Region"  # Changed from MSSA to E. coli
    ) +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold", size = 12),
      plot.subtitle = element_text(hjust = 0.5, size = 10),
      legend.position = "right",
      legend.title = element_text(size = 8),
      legend.text = element_text(size = 6),
      plot.margin = margin(0.5, 0.5, 0.5, 0.5, "cm")
    )
}

# Create maps for each period
map_pre <- create_period_map("Pre-COVID (2014-2019)", period_averages)
map_during <- create_period_map("During COVID (2020-2022)", period_averages)
map_post <- create_period_map("Post-COVID (2023)", period_averages)

# Combine the maps in a row
combined_plot_2 <- map_pre + map_during + map_post +
  plot_annotation(
    title = "E. coli bacteraemia rates, England Regions, by Covid Period (2014-2023)",  # Changed from MSSA to E. coli
    theme = theme(
      plot.title = element_text(hjust = 0.5, face = "bold", size = 14)
    )
  )

# Display the plot
print(combined_plot_2)

# Save the plot if needed
ggsave("ecoli_covid_periods_map.png", combined_plot, width = 15, height = 5)  # Changed filename from mssa to ecoli